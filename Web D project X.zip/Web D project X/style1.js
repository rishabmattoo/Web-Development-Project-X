document.getElementById('buttonLED'+id).onclick = writeLED(1,1);
var slides=document.querySelector('.rec3').children;
 var nextSlide=document.querySelector("arr2");
 var prevSlide=document.querySelector("arr1");
var totalSlides=slides.length;
var index=0;
nextSlide.onclick=function(){
    next("next");
}
prevSlide.onclick=function(){
    next("prev");
}
function next(direction){
    if(direction=="next"){
        index++;
        if(index==totalSlides){
            index=0;
        }
    }
    else{
             if(index==0){
                 index=totalSlides-1;
             }
             else{
                 index--;
             }
    }
    for(i=0;i<slides.length;i++){
        slides[i].classList.remove("active");

    }
    slides[index].classList.add("active");
}

// var carouselOneByOne = new PureJSCarousel({
//     carousel: '#carousel-one-by-one',
//     slide: '.slide',
//     oneByOne: true
//   });


